@echo off
rem Runs bridge.mjs with this computer's Node.js (20 or newer).
node "%~dp0bridge.mjs" %*
