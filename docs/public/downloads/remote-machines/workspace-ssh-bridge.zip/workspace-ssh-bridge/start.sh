#!/bin/sh
# Runs bridge.mjs with this computer's Node.js (20 or newer).
exec node "$(dirname "$0")/bridge.mjs" "$@"
