# Workspace SSH bridge 1.3.0

Lets a Workspace attach machines **over SSH, with nothing installed on them**: files, terminals,
logs, metrics, open ports and web previews all go through plain shell commands over SSH. A
browser can't open SSH connections itself, so run this bridge on your computer (or a server) and
keep it running while you use SSH machines. Needs **Node.js 20 or newer**.

```sh
node bridge.mjs                                       # or: ./start.sh (start.cmd on Windows)
node bridge.mjs --origin https://panel.example.com    # for a workspace hosted at that address
```

Then in the Workspace: **Containers → Attach a container → SSH**. The **SSH bridge** box should
say "Bridge running" (the default address is `http://localhost:7090`). Stop it with Ctrl+C.

| Option | |
| --- | --- |
| `--port <n>` | Port (default 7090; set the same address in the SSH bridge box) |
| `--host <addr>` | Address to listen on (default 127.0.0.1, this computer only) |
| `--origin <url>` | A workspace origin allowed to use it, repeatable (default: any localhost page) |
| `--token <t>` | An access token the workspace must send (`WORKSPACE_BRIDGE_TOKEN` works too). Generated and printed when `--host` isn't localhost. |
| `--preview-domain <d>` | Web previews at `https://<id>.<d>` behind a wildcard proxy |

- Only pages from allowed origins can use it. Passwords and keys stay in memory only while a
  machine is connected; the workspace keeps saved sign-ins encrypted in the browser.
- A workspace on a public `https://` site can still reach a bridge on your computer (start it
  with `--origin` for that site); Chrome may ask once to allow access to local network devices.
- The machines need `sshd` and the usual commands (`sh`, `stat`, `find`, `ps`, `tail`; `ss` for
  port names). Metrics need Linux.
